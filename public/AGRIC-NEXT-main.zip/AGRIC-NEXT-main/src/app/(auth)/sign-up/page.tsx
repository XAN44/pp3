import SignUpForm from "@/components/form/SignUpForm";

const page = () => {
  return (
    <div className="">
      <SignUpForm />
    </div>
  );
};

export default page;
