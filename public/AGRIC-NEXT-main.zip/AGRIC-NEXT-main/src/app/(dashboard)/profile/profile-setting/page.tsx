"use client";
import React from "react";
import ChangeNickname from "@/components/profile-name/ChangeNickName";
import { useSession } from "next-auth/react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";
import { ExclamationTriangleIcon } from "@radix-ui/react-icons";
import { ImgProfilee } from "@/components/profile-image/imgProfile";
import { AlertAuth } from "@/lib/alert/alertSession";

export default function Page() {
  const { data: session, status } = useSession();

  if (status === "unauthenticated") {
    return (
      <>
        <AlertAuth />
      </>
    );
  }

  if (status === "loading") {
    return (
      <>
        <AlertAuth />
      </>
    );
  }

  if (status === "authenticated") {
    return (
      <>
        <div className="grid text-center ">
          <ChangeNickname />
        </div>
      </>
    );
  }
}
