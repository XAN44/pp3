"use client";
import React, { FormEvent, useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { z } from "zod";
import { useForm, useWatch } from "react-hook-form";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "@/components/ui/use-toast";
import { db } from "@/lib/db";
import { GetServerSideProps } from "next";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const fromSchema = z.object({
  nickname: z
    .string()
    .min(1, "กรอกมากกว่า 1 ตัวอักษร")
    .max(20, "ห้ามมากกว่า 20 ตัว"),
});

export default function ChangeNickname() {
  const { data: session, status } = useSession();
  const [nickname, setNickname] = useState("");

  const form = useForm<z.infer<typeof fromSchema>>({
    resolver: zodResolver(fromSchema),
    defaultValues: {
      nickname: "",
    },
  });

  const { control, handleSubmit } = form;

  const fetchData = async () => {
    try {
      const response = await fetch("/api/profile-api");
      const data = await response.json();
      setNickname(data?.user?.nickname || " ไม่มีชื่อเล่น ");
    } catch (error) {
      console.error("Error fetching nickname:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const changeNickname = async (values: z.infer<typeof fromSchema>) => {
    const response = await fetch("/api/profile-api", {
      method: "POST",
      headers: {
        "Content-Type": "application/json ",
      },
      body: JSON.stringify({
        nickname: values.nickname,
      }),
    });
    if (response.ok) {
      toast({
        title: "สำเร็จ!",
        description: "เปลี่ยนชื่อเล่นสำเร็จ",
        variant: "default",
      });
      setNickname(values.nickname);
    } else {
      toast({
        title: "ไม่สำเร็จ!",
        description: "เปลี่ยนชื่อเล่นไม่สำเร็จ",
        variant: "destructive",
      });
    }
  };

  if (status === "loading") {
    return <div>Loading ...</div>;
  }

  if (status === "authenticated") {
    return (
      <>
        {nickname}
        <Dialog>
          <DialogTrigger>
            <Button variant="outline"> เปลี่ยนชื่อเล่น </Button>
          </DialogTrigger>

          <DialogContent>
            <DialogHeader>
              <DialogTitle> เปลี่ยนชื่อเล่น </DialogTitle>
              <DialogDescription>เปลี่ยนชื่อเล่นของคุณ</DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(changeNickname)}>
                <FormField
                  control={form.control}
                  name="nickname"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ชื่อเล่น</FormLabel>
                      <FormControl>
                        <div className="flex w-full max-w-sm items-center space-x-2">
                          <Input
                            placeholder="กรอกชื่อเล่นที่ต้องการเปลี่ยน"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </Form>
            <DialogFooter>
              <Button onClick={handleSubmit(changeNickname)}>บันทึก</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }
}
