'use server'
import { db } from "@/lib/db";
import { getCurrentUser } from "../session";


interface Params {
    userId: string;
    image: string;

}

export async function updateImage({
    userId,
    image,

}: Params): Promise<void> {

    try {
        const currentUser = await getCurrentUser();
        if (!currentUser) {
            throw new Error("User not found");
        }
        await db.user.update({
            where: {
                id: currentUser.id,
            },
            data: {
                image,
            },
        });
    } catch (error: any) {
        throw new Error(`Failed to create/update user: ${error.message}`);
    }
}




interface Params_bio {
    userId: string;
    bio: string;
}

export async function updateBio({
    userId,
    bio,
}: Params_bio): Promise<void> {
    try {
        const currentUser1 = await getCurrentUser();
        if (!currentUser1) {
            throw new Error("user not found")
        }
        await db.user.update({
            where: { id: currentUser1.id },
            data: { bio }
        })
    } catch (error: any) {
        throw new Error(`Failed to create/update user: ${error.message}`);

    }
}


interface Params_Name {
    userId: string;
    name: string;
}

export async function updateName({
    userId,
    name,
}: Params_Name): Promise<void> {
    try {
        const currentUser1 = await getCurrentUser();
        if (!currentUser1) {
            throw new Error("user not found")
        }
        await db.user.update({
            where: { id: currentUser1.id },
            data: { name }
        })
    } catch (error: any) {
        throw new Error(`Failed to create/update user: ${error.message}`);

    }
}


interface Params_Nickname {
    userId: string;
    nickname: string;
}

export async function updateNickname({
    userId,
    nickname,
}: Params_Nickname): Promise<void> {
    try {
        const currentUser1 = await getCurrentUser();
        if (!currentUser1) {
            throw new Error("user not found")
        }
        await db.user.update({
            where: { id: currentUser1.id },
            data: { nickname }
        })
    } catch (error: any) {
        throw new Error(`Failed to create/update user: ${error.message}`);

    }
}