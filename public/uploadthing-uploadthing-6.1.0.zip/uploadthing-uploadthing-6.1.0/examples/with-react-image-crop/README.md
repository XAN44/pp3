## Basic App Router example

<a href="https://stackblitz.com/github/pingdotgg/uploadthing/tree/main/examples/with-react-image-crop">
  <img height="64" src="https://github.com/pingdotgg/uploadthing/assets/51714798/45907a4e-aa64-401a-afb3-b6c6df6eb71f" />
</a>

Example using the NextJS App Router

```bash
pnpm install
pnpm dev
```
