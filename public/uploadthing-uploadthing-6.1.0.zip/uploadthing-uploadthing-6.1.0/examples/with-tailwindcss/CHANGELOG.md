# @example/tailwindcss

## null

### Patch Changes

- Updated dependencies
  [[`2e8b410`](https://github.com/pingdotgg/uploadthing/commit/2e8b410bb15c2688e9b6938c4a2cd17cf6110289)]:
  - uploadthing@5.5.3

## null

### Patch Changes

- Updated dependencies
  [[`8cfdade`](https://github.com/pingdotgg/uploadthing/commit/8cfdade9fee61a636fa1c88bc9380d4ac77e91d9)]:
  - uploadthing@5.5.2

## null

### Patch Changes

- Updated dependencies
  [[`353f6d0`](https://github.com/pingdotgg/uploadthing/commit/353f6d026fbee7480573d735d0406477dcb9e0bc)]:
  - uploadthing@5.5.1
