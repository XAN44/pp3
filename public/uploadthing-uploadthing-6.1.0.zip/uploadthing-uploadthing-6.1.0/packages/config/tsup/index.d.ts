declare module "@uploadthing/tsup-config" {
  import { Options } from "tsup";
  export const config: Options;
}
