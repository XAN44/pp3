This began as a fork of [mime-types](https://github.com/jshttp/mime-types) to be
an edge-compatible version. It has since been modified to further suit our needs

See the original license for the original source code in [LICENSE](./LICENSE)
